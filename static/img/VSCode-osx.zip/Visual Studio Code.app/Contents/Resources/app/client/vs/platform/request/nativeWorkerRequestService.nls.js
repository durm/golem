/*---------------------------------------------------------
 * Copyright (C) Microsoft Corporation. All rights reserved.
 *--------------------------------------------------------*/
define("vs/platform/request/nativeWorkerRequestService.nls",[],{vs_platform_request_nativeWorkerRequestService:["File not found"]});