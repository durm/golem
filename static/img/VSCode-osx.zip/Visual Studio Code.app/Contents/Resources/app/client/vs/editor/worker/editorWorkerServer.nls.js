/*---------------------------------------------------------
 * Copyright (C) Microsoft Corporation. All rights reserved.
 *--------------------------------------------------------*/
define("vs/editor/worker/editorWorkerServer.nls",[],{vs_base_severity:["Error","Warning","Info"],vs_platform_configuration_keybindings:["Ctrl","Shift","Alt","Command","Windows"],vs_editor_core_model_textModelWithTokens:["The mode has failed while tokenizing the input."]});