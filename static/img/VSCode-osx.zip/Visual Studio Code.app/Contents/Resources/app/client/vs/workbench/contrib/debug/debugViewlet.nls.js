/*---------------------------------------------------------
 * Copyright (C) Microsoft Corporation. All rights reserved.
 *--------------------------------------------------------*/
define("vs/workbench/contrib/debug/debugViewlet.nls",[],{vs_workbench_contrib_debug_debugViewlet:["Variables","Call Stack","Paused on exception: ","Breakpoints","There is no currently opened folder.","Open a folder in order to be able to debug."]});