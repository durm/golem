/*---------------------------------------------------------
 * Copyright (C) Microsoft Corporation. All rights reserved.
 *--------------------------------------------------------*/
define("vs/languages/markdown/markdownWorker.nls",[],{vs_languages_markdown_markdownSnippets:["Insert bold text","Insert italic text","Insert quoted text","Insert code","Insert fenced code block","Insert heading","Insert unordered list","Insert ordered list","Insert horizontal rule","Insert link","Insert image"]});