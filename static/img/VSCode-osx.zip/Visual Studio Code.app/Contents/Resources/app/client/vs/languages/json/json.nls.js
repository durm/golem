/*---------------------------------------------------------
 * Copyright (C) Microsoft Corporation. All rights reserved.
 *--------------------------------------------------------*/
define("vs/languages/json/json.nls",[],{vs_platform_configuration_configurationRegistry:["User specific settings","Workspace settings","Default settings"],vs_languages_json_json:["objects","arrays","strings","numbers","booleans","undefined"]});