/*---------------------------------------------------------
 * Copyright (C) Microsoft Corporation. All rights reserved.
 *--------------------------------------------------------*/
define("vs/workbench/contrib/search/openAnythingHandler.nls",[],{vs_workbench_contrib_search_openFileHandler:["search results"],vs_workbench_contrib_search_openSymbolHandler:["There is currently no language active that provides symbol information","symbol results","No symbols matching","Type to search for symbols"],vs_workbench_contrib_search_openAnythingHandler:["file and symbol results"]});